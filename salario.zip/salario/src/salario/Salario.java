package salario;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Salario extends javax.swing.JFrame {
    float bn, hx, ob,sueldob, res, tH,res2, res3;
//byKeizuke    
    public Salario() {
        initComponents();
    }

      @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtnombre = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtdireccion = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtsueldobase = new javax.swing.JTextPane();
        btncalcular = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtresultado = new javax.swing.JTextPane();
        chkbono = new javax.swing.JCheckBox();
        chkhorasextras = new javax.swing.JCheckBox();
        chkotros = new javax.swing.JCheckBox();
        comboLista = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        intHorasExtras = new javax.swing.JTextPane();
        jScrollPane6 = new javax.swing.JScrollPane();
        intOtrosBonos = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        txtnombre.setToolTipText("ingrese un nombre");
        jScrollPane1.setViewportView(txtnombre);

        txtdireccion.setToolTipText("ingrese una direccion");
        jScrollPane2.setViewportView(txtdireccion);

        jScrollPane3.setViewportView(txtsueldobase);

        btncalcular.setText("Calcular");
        btncalcular.setToolTipText("calcular sueldo");
        btncalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalcularActionPerformed(evt);
            }
        });

        jScrollPane4.setViewportView(txtresultado);

        chkbono.setText("Bono");
        chkbono.setToolTipText("Bono equivalente a 250");
        chkbono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkbonoActionPerformed(evt);
            }
        });

        chkhorasextras.setText("Horas extras");
        chkhorasextras.setToolTipText("horas extras trabajadas");
        chkhorasextras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkhorasextrasActionPerformed(evt);
            }
        });

        chkotros.setText("Otros bonos");
        chkotros.setToolTipText("Otros bonos");
        chkotros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkotrosActionPerformed(evt);
            }
        });

        comboLista.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un Dato", "Administrador", "Jefe de Sistemas", "Auditor", "Otro" }));
        comboLista.setToolTipText("Puestos o Cargos");
        comboLista.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboListaItemStateChanged(evt);
            }
        });
        comboLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboListaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Nombre");
        jLabel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jLabel1MouseMoved(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Direccion");
        jLabel2.setToolTipText("Ingrese una direccion");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Salario Base");

        intHorasExtras.setToolTipText("ingresar nuemro de horas extras");
        jScrollPane5.setViewportView(intHorasExtras);

        intOtrosBonos.setToolTipText("ingresar la cantidad monetaria a pagar");
        jScrollPane6.setViewportView(intOtrosBonos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addComponent(jScrollPane2)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btncalcular)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(chkbono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(chkhorasextras, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(chkotros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(comboLista, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(33, 33, 33))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(71, 71, 71))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(chkbono, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(chkhorasextras)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1))
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(chkotros)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22)
                .addComponent(comboLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btncalcular, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboListaActionPerformed
           String itemSeleccionado = (String)comboLista.getSelectedItem();
        if("Administrador".equalsIgnoreCase(itemSeleccionado)){
            txtsueldobase.setText("7000");
        }else if("Jefe de Sistemas".equalsIgnoreCase(itemSeleccionado)){
            txtsueldobase.setText("15000");
        }else if("Auditor".equalsIgnoreCase(itemSeleccionado)){
            txtsueldobase.setText("9000");
        }else if("Otro".equalsIgnoreCase(itemSeleccionado)){
            txtsueldobase.setText("5000");
        }
    }//GEN-LAST:event_comboListaActionPerformed

    private void comboListaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboListaItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_comboListaItemStateChanged

    private void chkhorasextrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkhorasextrasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkhorasextrasActionPerformed

    private void chkotrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkotrosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkotrosActionPerformed

    public void calculos(){
        
        try{ 
            

        if(chkbono.isSelected()){
            bn=250;
            sueldob = Float.parseFloat(txtsueldobase.getText());
            res = bn + sueldob;
            txtresultado.setText(String.valueOf(res));
        }else{
            bn=0;}
        

        if(chkhorasextras.isSelected()){
            
            sueldob = Float.parseFloat(txtsueldobase.getText());

            
            tH = Float.parseFloat(intHorasExtras.getText());
            res2 = (800 * tH) + sueldob;
            txtresultado.setText(String.valueOf(res2));
            
         }else{
             hx=0;}
         
        

         if (chkotros.isSelected()){
             ob=500;//Float.parseFloat(intOtrosBonos.getText());
             sueldob = Float.parseFloat(txtsueldobase.getText());
            res3 = ob + sueldob;
            txtresultado.setText(String.valueOf(res3));
         }else{
             ob=0;}
            
        }catch(NumberFormatException e){
            
        }
    }
    
    private void btncalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalcularActionPerformed
        

        if (txtnombre.getText().isEmpty() || txtdireccion.getText().isEmpty() || txtsueldobase.getText().isEmpty())
            
        {
            JOptionPane.showMessageDialog(null, "favor llene los valores vacio");
        }
        else
        {

        }   
            
        calculos();
    }//GEN-LAST:event_btncalcularActionPerformed

    private void chkbonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkbonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkbonoActionPerformed

    private void jLabel1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseMoved
            jLabel1.setToolTipText("ingresar un nombre");
    }//GEN-LAST:event_jLabel1MouseMoved

   
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Salario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Salario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Salario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Salario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Salario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncalcular;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox chkbono;
    private javax.swing.JCheckBox chkhorasextras;
    private javax.swing.JCheckBox chkotros;
    private javax.swing.JComboBox<String> comboLista;
    private javax.swing.JTextPane intHorasExtras;
    private javax.swing.JTextPane intOtrosBonos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextPane txtdireccion;
    private javax.swing.JTextPane txtnombre;
    private javax.swing.JTextPane txtresultado;
    private javax.swing.JTextPane txtsueldobase;
    // End of variables declaration//GEN-END:variables
}
